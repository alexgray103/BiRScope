function [I0, ret, phi, RGB_norm] = GPU_solve_qBRM(img, varargin)

    cmap = load('cmap_v3.mat').cmap;
    cmap = gpuArray(cmap);
    device = gpuDevice;
    device.CachePolicy = 'maximum';
    if ~isa(img, 'gpuArray')
        img = gpuArray(img);
    end
    
    [I0, phi, ret] = analytical_qBRM(img(:,:,1,:),img(:,:,2,:),img(:,:,3,:));
    
    phinew = gpuArray(phi);
    phinew = (phinew+pi/2)/pi;
    phinew = uint16((size(cmap,1)-1)*phinew)+1;
    r = reshape(cmap(phinew,1), [size(phinew,1),size(phinew,2),1,size(phinew,4)]);
    g = reshape(cmap(phinew,2), [size(phinew,1),size(phinew,2),1,size(phinew,4)]);
    b = reshape(cmap(phinew,3), [size(phinew,1),size(phinew,2),1,size(phinew,4)]);
    RGB = cat(3,r,g,b);
    clear r
    clear g
    clear b
    clear phinew
    ret = gpuArray(ret);
    RGB_norm = RGB.*ret;
    
    RGB_norm = gather(RGB_norm);
    clear RGB
    ret = gather(ret);
end