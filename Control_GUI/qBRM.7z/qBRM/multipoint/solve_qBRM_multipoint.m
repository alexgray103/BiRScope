function [ret, phi, Io] = solve_qBRM_multipoint(angles, img_corr)

    angles = reshape(angles,[1,1,length(angles)]);
    angles = deg2rad(angles);
%     a0 = (1/length(angles))*sum(img_corr(:,:,idx),3);
%     a1 = (2/length(angles))*sum(double(img_corr(:,:,idx)).*sin(2*angles),3);
%     b1 = (2/length(angles))*sum(double(img_corr(:,:,idx)).*cos(2*angles),3);
    a0 = (1/length(angles))*sum(img_corr,3);
    a1 = (2/length(angles))*sum(double(img_corr).*sin(2*angles),3);
    b1 = (2/length(angles))*sum(double(img_corr).*cos(2*angles),3);
    ret = (sqrt((a1.^2) + (b1.^2)))./a0;
%     phi = asin(-b1./(sqrt((a1.^2) + (b1.^2))));
%     if b1>a1
        phi = asin(-a1./(sqrt((a1.^2) + (b1.^2))));
%     end
%     if a1>b1
%         phi = acos(b1./(sqrt((a1.^2) + (b1.^2))));
%     end
%     if a1==b1
%         phi=0.5*pi/4;
%     end
    Io = a0*2;
end