function [I0,phinew,retconst,RGB_normalized]=multipointGlaserM(images,angles)
    I=double(images);
    % I=phicrop;
    angles=angles*pi/180;
    angs = reshape(angles,[1,1,length(angles)]);
%     angles = deg2rad(angles);
%     for kk=1:size(I,1)
%         for jj=1:size(I,2)
%             a0(kk,jj)=sum(1/length(angs).*I(kk,jj,:));
%             a1(kk,jj)=sum(2/length(angs).* squeeze(I(kk,jj,:))'.*sin(2*angs));
%             a2(kk,jj)=sum(2/length(angs).*squeeze(I(kk,jj,:))' .*cos(2*angs));
%         end
%     end
    a0 = (1/length(angs))*sum(images,3);
    a1 = (2/length(angs))*sum(double(images).*sin(2*angs),3);
    a2 = (2/length(angs))*sum(double(images).*cos(2*angs),3);

    I0=2*a0;
    retconst=sqrt((a1.^2+a2.^2))./(a0);
    
    phia2=0.5*asin(-a2./(sqrt(a1.^2+a2.^2)));
%     phia2f=0.5*asin(a2./(sqrt(a1.^2+a2.^2)));
    
    % phia2shift=phia2-pi/2;
    % phia2shift(phia2shift<-pi/2)=phia2shift(phia2shift<-pi/2)+pi;
    % phia2=phia2shift;
    
    phitestplus=phia2+pi/2;
    phitestminus=pi/2-phia2;
    % phitestplusf=phia2f+pi/2;
    % phitestminusf=pi/2-phia2f;
    
    minbound=-0.01;
    maxbound=+0.01;
    % api2=phia2>(pi/2-0.001) & phia2<(pi/2+0.001);
    a1b=a0.*retconst.*cos(2*phia2)>(a1+minbound) & a0.*retconst.*cos(2*phia2)<(a1+maxbound);
    % a1f=a0.*retconst.*cos(2*phia2f)>(a1+minbound) & a0.*retconst.*cos(2*phia2f)<(a1+maxbound);
    a1_p=a0.*retconst.*cos(2*phitestplus)>(a1+minbound) & a0.*retconst.*cos(2*phitestplus)<(a1+maxbound);
    a1_m=a0.*retconst.*cos(2*phitestminus)>(a1+minbound) & a0.*retconst.*cos(2*phitestminus)<(a1+maxbound);
    % a1_pf=a0.*retconst.*cos(2*phitestplusf)>(a1+minbound) & a0.*retconst.*cos(2*phitestplusf)<(a1+maxbound);
    % a1_mf=a0.*retconst.*cos(2*phitestminusf)>(a1+minbound) & a0.*retconst.*cos(2*phitestminusf)<(a1+maxbound);
    
    % base=a1Rb+a1f+a1_p+a1_m+a1_pf+a1_mf;
    % totphi=
    a1pt=a1b<1 & a1_m<1 & a1_p>0;
    a1mt=a1b<1 & a1_m>0;
    totphi=a1b.*phia2+a1mt.*(phitestminus);
    totphi=totphi+a1pt.*(phitestplus);
    
%     sh=70;
    sh=70;
    phi2=totphi+pi/2;
    phi2(isnan(phi2))=0;
    %find shift
    phi1=phi2;
   
    shift = zeros(size(phi1,1),size(phi1,2),size(phi1,4));
    phi_sh = zeros(size(phi1));
    %apply shift to data
    for j=1:size(totphi,4)
        shift(:,:,j) = sh*pi/180-mean(mean(phi1(:,:,1,j)));
        phi_sh(:,:,:,j) = mod(phi2(:,:,1,j)+shift(:,:,j), pi);
    end
    phinew = (phi_sh)/pi;
    
    cmap = load('C:\Users\BMOadmin2\Documents\Control_GUI\BRMscope\Functions\qBRM\cmap_v3.mat').cmap; 

    [RGB, RGB_normalized] = convert_phi_to_RGB_m(phinew,cmap, retconst);
%     figure(),imshow(RGB_normalized)
end