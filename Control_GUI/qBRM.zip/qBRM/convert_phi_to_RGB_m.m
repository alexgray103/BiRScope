function [RGB, RGB_normalized] = convert_phi_to_RGB_m(phi,cmap, ret, varargin)
%     % wicked fast
%     phinew = (phi+pi/2)/pi;
%     phinew2 = uint16((size(cmap,1)-1)*phinew)+1;
%     rgb = zeros([size(ret,1),size(ret,2),3,size(ret,4)], 'gpuArray');
%     rgb = cmap(phinew2,:);
%     r = reshape(rgb(:,1),[2960,2960,1,size(phi,4)]);
%     g = reshape(rgb(:,2),[2960,2960,1,size(phi,4)]);
%     b = reshape(rgb(:,3),[2960,2960,1,size(phi,4)]);
%     clear rgb
%     RGB = cat(3,r,g,b);
%     clear r g b
%     ret = gpuArray(ret);
%     RGB_normalized = RGB.*(ret);
% 
%     %
    phinew = gpuArray(phi);
%     phinew = (phinew+pi/2)/pi;
    phinew = uint16((size(cmap,1)-1)*phinew)+1;
    r = reshape(cmap(phinew,1), [size(phinew,1),size(phinew,2),1,size(phinew,4)]);
    g = reshape(cmap(phinew,2), [size(phinew,1),size(phinew,2),1,size(phinew,4)]);
    b = reshape(cmap(phinew,3), [size(phinew,1),size(phinew,2),1,size(phinew,4)]);
    RGB = cat(3,r,g,b);
    clear r
    clear g
    clear b
    clear phinew
    ret = gpuArray(ret);
    RGB_norm = RGB.*ret;
    ret = gather(ret);
    RGB_normalized = gather(RGB_norm);
%     clear RGB
    %

%     phinew = mat2gray(phi);
%     phinew2 = uint16(size(cmap,1)*phinew);
%     RGB = ind2rgb(phinew2,cmap);
%     %ret = mat2gray(ret); % rescale retardance to 0-1 range
%     RGB_normalized = RGB.*(ret);    

% second attempt to speed up with gpu
%     phinew = mat2gray(phi);
%     phinew2 = squeeze(uint16(size(cmap,1)*phinew));
%     phi_vectorized = phinew2(:);
%     rgb = ind2rgb(phi_vectorized,cmap);
%     r = reshape(rgb(:,1),[2960,2960,1,20]);
%     g = reshape(rgb(:,2),[2960,2960,1,20]);
%     b = reshape(rgb(:,3),[2960,2960,1,20]);
%     RGB = cat(3,r,g,b);
%     %ret = mat2gray(ret); % rescale retardance to 0-1 range
%     RGB_normalized = RGB.*(ret);

    
   
end